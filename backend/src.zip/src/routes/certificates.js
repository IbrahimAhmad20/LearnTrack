const router = require("express").Router();
const { param, query } = require("express-validator");
const {
  getMyCertificates,
  verifyCertificate,
  getAllCertificates,
  revokeCertificate,
} = require("../controllers/certificateController");
const { verifyToken, requireRole } = require("../middleware/auth");
const { validate } = require("../middleware/validate");

// Public — certificate verification (no auth required)
router.get(
  "/verify/:hash",
  param("hash").isLength({ min: 64, max: 64 }).isHexadecimal(),
  validate,
  verifyCertificate,
);

// Auth-gated routes
router.use(verifyToken);

// GET  /api/v1/certificates/me    — student
router.get("/me", requireRole("student"), getMyCertificates);

// GET  /api/v1/certificates       — admin
router.get(
  "/",
  requireRole("admin"),
  query("page").optional().isInt({ min: 1 }),
  query("limit").optional().isInt({ min: 1, max: 100 }),
  validate,
  getAllCertificates,
);

// DELETE /api/v1/certificates/:certId — admin (revoke)
router.delete(
  "/:certId",
  requireRole("admin"),
  param("certId").isInt({ min: 1 }),
  validate,
  revokeCertificate,
);

module.exports = router;
