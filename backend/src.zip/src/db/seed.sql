-- ============================================================
-- LearnTrack v2 – Seed Data (UUID edition)
-- ============================================================
-- NOTE: In a real Supabase project, users are created via
-- supabase.auth.admin.createUser() which generates UUIDs.
-- These static UUIDs are for local dev / testing only.
-- ============================================================

-- Static test UUIDs
-- admin:      00000000-0000-0000-0000-000000000001
-- instructor: 00000000-0000-0000-0000-000000000002
-- student:    00000000-0000-0000-0000-000000000003

-- ── USERS ────────────────────────────────────────────────────────────────────
-- password for all test accounts: TestPass123!
-- bcrypt hash (12 rounds) of 'TestPass123!'
INSERT INTO users (user_id, full_name, email, password, role) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Admin User',       'admin@learntrack.dev',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2NnfVlJ5dS', 'admin'),
  ('00000000-0000-0000-0000-000000000002', 'Jane Instructor',  'instructor@learntrack.dev',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2NnfVlJ5dS', 'instructor'),
  ('00000000-0000-0000-0000-000000000003', 'John Student',     'student@learntrack.dev',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj2NnfVlJ5dS', 'student');

-- ── INSTRUCTORS ───────────────────────────────────────────────────────────────
INSERT INTO instructors (user_id, department, qualification) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Administration', 'MSc Computer Science'),
  ('00000000-0000-0000-0000-000000000002', 'Engineering',    'PhD Software Engineering');

-- ── COURSES ───────────────────────────────────────────────────────────────────
INSERT INTO courses (instructor_id, title, description, category, is_published) VALUES
  (1, 'Introduction to Python', 'Learn Python from scratch.', 'Programming', TRUE),
  (2, 'Web Development Basics', 'HTML, CSS and JavaScript fundamentals.', 'Web', TRUE),
  (2, 'Advanced Node.js',       'Deep dive into Node.js and Express.', 'Backend', FALSE);

-- ── CONTENT ───────────────────────────────────────────────────────────────────
-- content_type_id: 1=video, 2=document, 3=quiz
INSERT INTO content (course_id, content_type_id, title, duration_sec, sort_order, is_published) VALUES
  (1, 1, 'What is Python?',        600,  1, TRUE),
  (1, 1, 'Variables and Types',    720,  2, TRUE),
  (1, 2, 'Python Cheatsheet PDF', NULL,  3, TRUE),
  (2, 1, 'HTML Basics',           540,  1, TRUE),
  (2, 1, 'CSS Fundamentals',      660,  2, TRUE);

-- ── ENROLLMENTS ───────────────────────────────────────────────────────────────
-- status_id: 1=active
INSERT INTO enrollments (user_id, course_id, status_id) VALUES
  ('00000000-0000-0000-0000-000000000003', 1, 1),
  ('00000000-0000-0000-0000-000000000003', 2, 1);

-- ── QUIZ ─────────────────────────────────────────────────────────────────────
INSERT INTO quiz (course_id, title, pass_score, allow_multiple, is_published) VALUES
  (1, 'Python Basics Quiz', 70, TRUE, TRUE);

-- ── QUIZ QUESTIONS ────────────────────────────────────────────────────────────
-- question_type_id: 1=mcq, 2=true_false
INSERT INTO quiz_questions (quiz_id, question_type_id, question_text, sort_order, points) VALUES
  (1, 1, 'Which keyword defines a function in Python?', 1, 1),
  (1, 2, 'Python is a statically typed language.',      2, 1);

-- ── QUESTION OPTIONS ─────────────────────────────────────────────────────────
-- Question 1 options
INSERT INTO question_options (question_id, option_text, is_correct, sort_order) VALUES
  (1, 'def',      TRUE,  1),
  (1, 'function', FALSE, 2),
  (1, 'fn',       FALSE, 3),
  (1, 'func',     FALSE, 4);

-- Question 2 options (true_false)
INSERT INTO question_options (question_id, option_text, is_correct, sort_order) VALUES
  (2, 'True',  FALSE, 1),
  (2, 'False', TRUE,  2);
