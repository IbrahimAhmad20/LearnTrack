const { supabase } = require("../db/connection");

// ── GET /api/v1/certificates/me ───────────────────────────────────────────────
// Student — all certificates earned by the logged-in user
async function getMyCertificates(req, res, next) {
  try {
    const { data, error } = await supabase
      .from("certificates")
      .select(
        `
        cert_id, issued_at, cert_url, verify_hash,
        courses (
          course_id, title, thumbnail_url,
          instructors ( users ( full_name ) )
        )
      `,
      )
      .eq("user_id", req.user.user_id)
      .order("issued_at", { ascending: false });

    if (error) throw new Error(error.message);
    res.json(data || []);
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/certificates/verify/:hash ────────────────────────────────────
// Public — verify a certificate by its verify_hash (no auth required)
// Returns enough info to confirm authenticity without exposing user PII
async function verifyCertificate(req, res, next) {
  try {
    const { hash } = req.params;

    if (!hash || hash.length !== 64) {
      return res.status(400).json({ error: "Invalid verification hash" });
    }

    const { data, error } = await supabase
      .from("certificates")
      .select(
        `
        cert_id, issued_at,
        users   ( full_name ),
        courses ( title )
      `,
      )
      .eq("verify_hash", hash)
      .maybeSingle();

    if (error) throw new Error(error.message);

    if (!data) {
      return res.status(404).json({
        valid: false,
        message:
          "Certificate not found. It may have been revoked or the link is incorrect.",
      });
    }

    res.json({
      valid: true,
      holder_name: data.users?.full_name,
      course: data.courses?.title,
      issued_at: data.issued_at,
    });
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/certificates (admin only) ─────────────────────────────────────
// Admin — paginated list of all issued certificates
async function getAllCertificates(req, res, next) {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Number(req.query.limit) || 50);
    const offset = (page - 1) * limit;

    const { data, error, count } = await supabase
      .from("certificates")
      .select(
        `
        cert_id, issued_at, verify_hash,
        users   ( user_id, full_name, email ),
        courses ( course_id, title )
      `,
        { count: "exact" },
      )
      .order("issued_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw new Error(error.message);

    res.json({
      certificates: data || [],
      total: count ?? 0,
      page,
      totalPages: Math.ceil((count ?? 0) / limit),
    });
  } catch (err) {
    next(err);
  }
}

// ── DELETE /api/v1/certificates/:certId (admin only) ─────────────────────────
// Admin — revoke a certificate
async function revokeCertificate(req, res, next) {
  try {
    const certId = Number(req.params.certId);

    const { data: cert } = await supabase
      .from("certificates")
      .select("cert_id")
      .eq("cert_id", certId)
      .maybeSingle();

    if (!cert) return res.status(404).json({ error: "Certificate not found" });

    const { error } = await supabase
      .from("certificates")
      .delete()
      .eq("cert_id", certId);

    if (error) throw new Error(error.message);
    res.json({ message: "Certificate revoked" });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getMyCertificates,
  verifyCertificate,
  getAllCertificates,
  revokeCertificate,
};
