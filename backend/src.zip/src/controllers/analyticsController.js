const { supabase } = require('../db/connection');

// ── GET /api/v1/analytics/active-students ─────────────────────────────────────
async function activeStudents(req, res, next) {
  try {
    const { start, end } = req.query;

    let q = supabase
      .from('activity_log')
      .select('user_id, watch_time, users!inner(full_name, role)')
      .eq('users.role', 'student');

    if (start) q = q.gte('event_at', start);
    if (end)   q = q.lte('event_at', end);

    const { data, error } = await q;
    if (error) throw new Error(error.message);

    const totals = {};
    data.forEach(row => {
      const uid = row.user_id;
      if (!totals[uid]) totals[uid] = { user_id: uid, full_name: row.users.full_name, total_watch_sec: 0 };
      totals[uid].total_watch_sec += row.watch_time;
    });

    res.json(
      Object.values(totals)
        .sort((a, b) => b.total_watch_sec - a.total_watch_sec)
        .slice(0, 20)
    );
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/underperforming ─────────────────────────────────────
async function underperforming(req, res, next) {
  try {
    const threshold = Number(req.query.threshold) || 50;

    const { data, error } = await supabase
      .from('quiz_attempts')
      .select('user_id, score, users(full_name)');

    if (error) throw new Error(error.message);

    const totals = {};
    data.forEach(row => {
      const uid = row.user_id;
      if (!totals[uid]) totals[uid] = { user_id: uid, full_name: row.users.full_name, scores: [] };
      totals[uid].scores.push(row.score);
    });

    const result = Object.values(totals)
      .map(u => ({
        user_id:   u.user_id,
        full_name: u.full_name,
        avg_score: Math.round((u.scores.reduce((a, b) => a + b, 0) / u.scores.length) * 100) / 100,
      }))
      .filter(u => u.avg_score < threshold)
      .sort((a, b) => a.avg_score - b.avg_score);

    res.json(result);
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/skipped-content ─────────────────────────────────────
async function skippedContent(req, res, next) {
  try {
    const { course_id } = req.query;

    const { data: typeRow } = await supabase
      .from('activity_types')
      .select('type_id')
      .eq('type_name', 'skip')
      .single();

    const { data, error } = await supabase
      .from('activity_log')
      .select('content_id, content(title, course_id)')
      .eq('type_id', typeRow.type_id);

    if (error) throw new Error(error.message);

    const counts = {};
    data.forEach(row => {
      if (course_id && row.content.course_id !== Number(course_id)) return;
      const cid = row.content_id;
      if (!counts[cid]) counts[cid] = { content_id: cid, title: row.content.title, skip_count: 0 };
      counts[cid].skip_count++;
    });

    res.json(
      Object.values(counts)
        .sort((a, b) => b.skip_count - a.skip_count)
        .slice(0, 20)
    );
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/completion-rates ────────────────────────────────────
async function completionRates(req, res, next) {
  try {
    const { course_id } = req.query;

    const { data, error } = await supabase
      .from('content_progress')
      .select('user_id, progress_percent, users(full_name), content(course_id)');

    if (error) throw new Error(error.message);

    const totals = {};
    data.forEach(row => {
      if (course_id && row.content.course_id !== Number(course_id)) return;
      const uid = row.user_id;
      if (!totals[uid]) totals[uid] = { user_id: uid, full_name: row.users.full_name, values: [] };
      totals[uid].values.push(row.progress_percent);
    });

    res.json(
      Object.values(totals)
        .map(u => ({
          user_id:            u.user_id,
          full_name:          u.full_name,
          avg_completion_pct: Math.round((u.values.reduce((a, b) => a + b, 0) / u.values.length) * 100) / 100,
        }))
        .sort((a, b) => b.avg_completion_pct - a.avg_completion_pct)
    );
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/performance-trend/:userId ──────────────────────────
async function performanceTrend(req, res, next) {
  try {
    const userId = Number(req.params.userId);

    if (req.user.role === 'student' && req.user.user_id !== userId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { data, error } = await supabase
      .from('quiz_attempts')
      .select('score, passed, attempt_date, users(full_name), quiz(title)')
      .eq('user_id', userId)
      .order('attempt_date', { ascending: true });

    if (error) throw new Error(error.message);
    res.json(data);
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/dashboard/admin ────────────────────────────────────
// v2: performance_summary is now a materialized view (mv_performance_summary).
// course_stats reads from the view instead of the old plain table.
async function adminDashboard(req, res, next) {
  try {
    const [usersRes, coursesRes, enrollRes, sessionRes, courseStatsRes] = await Promise.all([
      supabase.from('users').select('user_id', { count: 'exact', head: true })
        .eq('is_active', true).is('deleted_at', null),
      supabase.from('courses').select('course_id', { count: 'exact', head: true })
        .is('deleted_at', null),
      supabase.from('enrollments').select('enrollment_id', { count: 'exact', head: true }),
      supabase.from('user_sessions').select('session_id', { count: 'exact', head: true })
        .is('logout_at', null),
      // v2: read from materialized view
      supabase.from('mv_performance_summary').select(`
        course_id,
        avg_quiz_score,
        completion_pct
      `),
    ]);

    res.json({
      total_users:       usersRes.count,
      total_courses:     coursesRes.count,
      total_enrollments: enrollRes.count,
      active_sessions:   sessionRes.count,
      course_stats:      courseStatsRes.data,
    });
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/analytics/instructor/:courseId ────────────────────────────────
// v2: reads from mv_performance_summary materialized view.
async function instructorDashboard(req, res, next) {
  try {
    const courseId = Number(req.params.courseId);

    const [enrollRes, topStudentsRes, atRiskRes] = await Promise.all([
      supabase.from('enrollments')
        .select('enrollment_id', { count: 'exact', head: true })
        .eq('course_id', courseId),

      // v2: mv_performance_summary instead of performance_summary table
      supabase.from('mv_performance_summary')
        .select('user_id, total_watch_sec, completion_pct, users(full_name)')
        .eq('course_id', courseId)
        .order('total_watch_sec', { ascending: false })
        .limit(5),

      supabase.from('mv_performance_summary')
        .select('user_id, avg_quiz_score, completion_pct, users(full_name)')
        .eq('course_id', courseId)
        .lt('avg_quiz_score', 50)
        .order('avg_quiz_score', { ascending: true }),
    ]);

    res.json({
      enrollment_count: enrollRes.count,
      top_students:     topStudentsRes.data,
      at_risk_students: atRiskRes.data,
    });
  } catch (err) {
    next(err);
  }
}

// ── POST /api/v1/analytics/refresh-summary ────────────────────────────────────
// v2: triggers a REFRESH on the materialized view via Supabase RPC.
// The old refreshSummary looped over every enrollment and ran N×4 queries —
// that's replaced by a single SQL call to refresh the view.
// Run this on a schedule (cron) or trigger it manually from the admin dashboard.
async function refreshSummary(req, res, next) {
  try {
    const { error } = await supabase.rpc('refresh_performance_summary');
    if (error) throw new Error(error.message);
    res.json({ message: 'Performance summary refreshed' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  activeStudents,
  underperforming,
  skippedContent,
  completionRates,
  performanceTrend,
  adminDashboard,
  instructorDashboard,
  refreshSummary,
};
