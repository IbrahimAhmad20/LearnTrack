const bcrypt = require('bcrypt');
const { supabase } = require('../db/connection');

// ── GET /api/v1/users/me ──────────────────────────────────────────────────────
async function getMe(req, res, next) {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('user_id, full_name, email, role, bio, avatar_url, created_at')
      .eq('user_id', req.user.user_id)
      .single();

    if (error || !data) return res.status(404).json({ error: 'User not found' });
    res.json(data);
  } catch (err) {
    next(err);
  }
}

// ── PUT /api/v1/users/me ──────────────────────────────────────────────────────
async function updateMe(req, res, next) {
  try {
    const { full_name, bio, avatar_url, password } = req.body;
    const updates = { updated_at: new Date().toISOString() };

    if (full_name)  updates.full_name  = full_name;
    if (bio)        updates.bio        = bio;
    if (avatar_url) updates.avatar_url = avatar_url;
    if (password)   updates.password   = await bcrypt.hash(password, 12);

    const { error } = await supabase
      .from('users')
      .update(updates)
      .eq('user_id', req.user.user_id);

    if (error) throw new Error(error.message);
    res.json({ message: 'Profile updated' });
  } catch (err) {
    next(err);
  }
}

// ── GET /api/v1/users  (admin only) ──────────────────────────────────────────
async function listUsers(req, res, next) {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('user_id, full_name, email, role, is_active, created_at')
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);
    res.json(data);
  } catch (err) {
    next(err);
  }
}

// ── DELETE /api/v1/users/:id  (admin only) ───────────────────────────────────
async function deleteUser(req, res, next) {
  try {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('user_id', Number(req.params.id));

    if (error) throw new Error(error.message);
    res.json({ message: 'User deleted' });
  } catch (err) {
    next(err);
  }
}

// ── PUT /api/v1/users/:id/status  (admin toggle active) ──────────────────────
async function setUserStatus(req, res, next) {
  try {
    const { error } = await supabase
      .from('users')
      .update({ is_active: req.body.is_active })
      .eq('user_id', Number(req.params.id));

    if (error) throw new Error(error.message);
    res.json({ message: 'User status updated' });
  } catch (err) {
    next(err);
  }
}

module.exports = { getMe, updateMe, listUsers, deleteUser, setUserStatus };
