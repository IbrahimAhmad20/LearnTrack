const bcrypt = require('bcrypt');
const jwt    = require('jsonwebtoken');
const { supabase } = require('../db/connection');
const { hashToken } = require('../middleware/auth');

const SALT_ROUNDS = 12;
const COOKIE_OPTS = {
  httpOnly: true,
  secure:   process.env.NODE_ENV === 'production',
  sameSite: 'strict',
  maxAge:   24 * 60 * 60 * 1000,
};

// ── POST /api/v1/auth/register ────────────────────────────────────────────────
async function register(req, res, next) {
  try {
    const { full_name, email, password, role = 'student' } = req.body;
    const safeRole = ['student', 'instructor', 'admin'].includes(role) ? role : 'student';

    // Check for duplicate BEFORE calling Supabase Auth so we get a clean 409
    const { data: existing } = await supabase
      .from('users')
      .select('user_id')
      .eq('email', email)
      .maybeSingle();

    if (existing) return res.status(409).json({ error: 'Email already registered' });

    // Create user in Supabase Auth — this generates the UUID
    const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { full_name, role: safeRole },
      email_confirm: true,
    });

    if (authErr) {
      // Supabase Auth also throws on duplicate — catch as 409
      if (authErr.message.toLowerCase().includes('already registered') ||
          authErr.message.toLowerCase().includes('already been registered') ||
          authErr.code === '23505') {
        return res.status(409).json({ error: 'Email already registered' });
      }
      throw new Error(authErr.message);
    }

    const userId = authData.user.id;   // UUID

    // The handle_new_auth_user trigger creates the users row automatically.
    // We upsert here as a fallback in case the trigger isn't wired yet.
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    const { error: upsertErr } = await supabase
      .from('users')
      .upsert({
        user_id:   userId,
        full_name,
        email,
        password:  hashedPassword,
        role:      safeRole,
      }, { onConflict: 'user_id' });

    if (upsertErr) throw new Error(upsertErr.message);

    // If instructor or admin, ensure the instructors row exists.
    // Retry once after a short delay — the handle_new_auth_user trigger and the
    // upsert above both touch the users table, and the instructors FK check
    // needs the users row to be fully committed first.
    if (safeRole === 'instructor' || safeRole === 'admin') {
      const { error: instErr } = await supabase
        .from('instructors')
        .upsert({ user_id: userId }, { onConflict: 'user_id' });

      if (instErr) {
        // Retry once after 200ms to let the users row settle
        await new Promise(r => setTimeout(r, 200));
        const { error: retryErr } = await supabase
          .from('instructors')
          .upsert({ user_id: userId }, { onConflict: 'user_id' });
        if (retryErr) {
          // Non-fatal — log but don't fail registration
          console.warn('Could not create instructors row:', retryErr.message);
        }
      }
    }

    res.status(201).json({ message: 'Registration successful', user_id: userId });
  } catch (err) {
    next(err);
  }
}

// ── POST /api/v1/auth/login ───────────────────────────────────────────────────
async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    // Authenticate via Supabase Auth
    const { data: authData, error: authErr } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authErr) return res.status(401).json({ error: 'Invalid credentials' });

    const userId = authData.user.id;   // UUID

    // Fetch our profile (has role, is_active, deleted_at)
    const { data: user } = await supabase
      .from('users')
      .select('user_id, full_name, email, role, is_active, deleted_at')
      .eq('user_id', userId)
      .maybeSingle();

    if (!user || user.deleted_at) return res.status(401).json({ error: 'Invalid credentials' });
    if (!user.is_active)          return res.status(403).json({ error: 'Account deactivated' });

    // Issue our own JWT (includes role for middleware checks)
    const payload = { user_id: user.user_id, email: user.email, role: user.role };
    const token   = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '24h',
    });

    // Record session
    await supabase.from('user_sessions').insert({
      user_id:    userId,
      token_hash: hashToken(token),
      ip_address: req.ip || null,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    });

    res.cookie('token', token, COOKIE_OPTS);
    res.json({
      token,
      user: { user_id: user.user_id, full_name: user.full_name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
}

// ── POST /api/v1/auth/logout ──────────────────────────────────────────────────
async function logout(req, res, next) {
  try {
    await supabase
      .from('user_sessions')
      .update({ logout_at: new Date().toISOString() })
      .eq('token_hash', hashToken(req.token))
      .eq('user_id', req.user.user_id);

    res.clearCookie('token');
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, logout };
