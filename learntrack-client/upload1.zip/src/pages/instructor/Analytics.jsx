import { useState, useEffect } from "react";
import { analytics } from "../../api";
import { StatCard, SkeletonCard } from "../../components/ui";

export default function Analytics() {
  const [active, setActive] = useState([]);
  const [completion, setCompletion] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([analytics.activeStudents(), analytics.completionRates()])
      .then(([a, c]) => {
        setActive(a.data);
        setCompletion(c.data);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-8 max-w-4xl page-enter">
      <div className="mb-8">
        <h1
          className="text-xl font-medium mb-1"
          style={{ color: "var(--text-primary)" }}
        >
          Analytics
        </h1>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
          Student engagement and performance across your courses.
        </p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-3 mb-8">
        <StatCard
          label="Active students"
          value={loading ? "—" : active.length}
          sub="with watch activity"
          accent
        />
        <StatCard
          label="Completion data"
          value={loading ? "—" : completion.length}
          sub="students tracked"
        />
      </div>

      {/* Active students table */}
      <div className="mb-3">
        <h2
          className="text-xs uppercase tracking-widest"
          style={{
            color: "var(--text-muted)",
            fontFamily: "DM Mono, monospace",
          }}
        >
          Most active students
        </h2>
      </div>

      <div className="card overflow-hidden mb-8">
        {loading ? (
          <div className="p-3 flex flex-col gap-2">
            {[1, 2, 3].map((i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : active.length === 0 ? (
          <div
            className="px-5 py-10 text-center text-sm"
            style={{ color: "var(--text-muted)" }}
          >
            No activity data yet. Students need to start watching content.
          </div>
        ) : (
          <div>
            {/* Header */}
            <div
              className="grid px-5 py-2.5 text-xs"
              style={{
                gridTemplateColumns: "1fr auto",
                color: "var(--text-muted)",
                borderBottom: "1px solid var(--border)",
                fontFamily: "DM Mono, monospace",
                textTransform: "uppercase",
                letterSpacing: "0.06em",
              }}
            >
              <span>Student</span>
              <span>Watch time</span>
            </div>
            {active.slice(0, 10).map((s, i) => (
              <div
                key={s.user_id}
                className="grid px-5 py-3 text-sm"
                style={{
                  gridTemplateColumns: "1fr auto",
                  borderBottom:
                    i < Math.min(active.length, 10) - 1
                      ? "1px solid var(--border)"
                      : "none",
                  alignItems: "center",
                }}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className="text-xs"
                    style={{
                      color: "var(--text-muted)",
                      fontFamily: "DM Mono, monospace",
                      minWidth: 20,
                    }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span style={{ color: "var(--text-primary)" }}>
                    {s.full_name}
                  </span>
                </div>
                <span
                  style={{
                    color: "var(--accent-text)",
                    fontFamily: "DM Mono, monospace",
                    fontSize: 12,
                  }}
                >
                  {Math.round(s.total_watch_sec / 60)}m
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Coming soon */}
      <div
        className="rounded p-5 text-center"
        style={{
          background: "var(--bg-raised)",
          border: "1px dashed var(--border-light)",
        }}
      >
        <p
          className="text-sm font-medium mb-1"
          style={{ color: "var(--text-secondary)" }}
        >
          More analytics coming soon
        </p>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          Quiz performance trends, completion funnels, and per-course breakdowns
        </p>
      </div>
    </div>
  );
}
npm;
