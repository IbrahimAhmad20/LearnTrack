import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Spinner, ErrorMessage } from "../../components/ui";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/instructor";

  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      const dest =
        user.role === "admin"
          ? "/admin"
          : user.role === "instructor"
            ? "/instructor"
            : "/dashboard";
      navigate(
        from === "/instructor" && user.role !== "instructor" ? dest : from,
        { replace: true },
      );
    } catch (err) {
      setError(err.response?.data?.error || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex" style={{ background: "var(--bg-base)" }}>
      {/* Left panel — branding */}
      <div
        className="hidden lg:flex flex-col justify-between p-12"
        style={{
          width: 420,
          background: "var(--bg-surface)",
          borderRight: "1px solid var(--border)",
          flexShrink: 0,
        }}
      >
        <div>
          <div className="flex items-baseline gap-1 mb-16">
            <span
              className="font-display text-2xl italic"
              style={{ color: "var(--accent)" }}
            >
              Learn
            </span>
            <span
              className="font-display text-2xl"
              style={{ color: "var(--text-primary)" }}
            >
              Track
            </span>
          </div>
          <blockquote>
            <p
              className="font-display text-3xl leading-snug italic"
              style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}
            >
              "Build courses that actually change how people learn."
            </p>
          </blockquote>
        </div>

        <div>
          <div
            className="rounded p-4 mb-6"
            style={{
              background: "var(--accent-dim)",
              border: "1px solid rgba(232,168,56,0.2)",
            }}
          >
            <p className="text-sm" style={{ color: "var(--accent-text)" }}>
              Instructor platform — create, publish, and track student progress
              across all your courses.
            </p>
          </div>
          <p
            className="text-xs"
            style={{
              color: "var(--text-muted)",
              fontFamily: "DM Mono, monospace",
            }}
          >
            LearnTrack v1.0 — Instructor Portal
          </p>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center px-6 page-enter">
        <div style={{ width: "100%", maxWidth: 380 }}>
          {/* Mobile logo */}
          <div className="flex items-baseline gap-1 mb-10 lg:hidden">
            <span
              className="font-display text-2xl italic"
              style={{ color: "var(--accent)" }}
            >
              Learn
            </span>
            <span
              className="font-display text-2xl"
              style={{ color: "var(--text-primary)" }}
            >
              Track
            </span>
          </div>

          <h1
            className="text-xl font-medium mb-1"
            style={{ color: "var(--text-primary)" }}
          >
            Welcome back
          </h1>
          <p
            className="text-sm mb-8"
            style={{ color: "var(--text-secondary)" }}
          >
            Sign in to your instructor account
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="label">Email</label>
              <input
                type="email"
                className="input-field"
                placeholder="you@university.edu"
                value={form.email}
                onChange={set("email")}
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label className="label">Password</label>
              <input
                type="password"
                className="input-field"
                placeholder="••••••••"
                value={form.password}
                onChange={set("password")}
                required
                autoComplete="current-password"
              />
            </div>

            <ErrorMessage message={error} />

            <button
              type="submit"
              className="btn-primary justify-center mt-1"
              disabled={loading}
              style={{ height: 38, opacity: loading ? 0.7 : 1 }}
            >
              {loading ? <Spinner size={16} /> : "Sign in"}
            </button>
          </form>

          <p
            className="text-sm mt-6 text-center"
            style={{ color: "var(--text-muted)" }}
          >
            No account?{" "}
            <Link
              to="/register"
              style={{ color: "var(--accent-text)" }}
              className="hover:underline"
            >
              Register as instructor
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
