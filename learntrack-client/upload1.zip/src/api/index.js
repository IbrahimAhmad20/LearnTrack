import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1",
  timeout: 15000,
});

// Attach token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("lt_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Global 401 handler
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("lt_token");
      localStorage.removeItem("lt_user");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  },
);

export default api;

// ── Typed helpers ──────────────────────────────────────────────────────────

export const auth = {
  register: (data) => api.post("/auth/register", data),
  login: (data) => api.post("/auth/login", data),
  logout: () => api.post("/auth/logout"),
  me: () => api.get("/users/me"),
};

export const courses = {
  list: (params) => api.get("/courses", { params }),
  get: (id) => api.get(`/courses/${id}`),
  create: (data) => api.post("/courses", data),
  update: (id, data) => api.put(`/courses/${id}`, data),
  delete: (id) => api.delete(`/courses/${id}`),
  addContent: (id, data) => api.post(`/courses/${id}/content`, data),
  students: (id) => api.get(`/courses/${id}/students`),
};

export const analytics = {
  activeStudents: (params) => api.get("/analytics/active-students", { params }),
  completionRates: (params) =>
    api.get("/analytics/completion-rates", { params }),
  underperforming: (params) =>
    api.get("/analytics/underperforming", { params }),
  instructorDash: (courseId) => api.get(`/analytics/instructor/${courseId}`),
};
